//
//  GADMAdapterAdColonyInitializer.h
//  AdColonyAdapter
//
//  Created by AdColony on 3/10/14.
//
//

#import <Foundation/Foundation.h>

@interface GADMAdapterAdColonyInitializer : NSObject

+ (void)startWithAppID:(NSString *)appID andZones:(NSArray *)zones;

@end

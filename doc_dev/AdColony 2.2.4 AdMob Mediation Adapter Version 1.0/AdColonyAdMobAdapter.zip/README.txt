AdColony 2.2.4 AdMob Mediation Adapter Version 1.0
-------------------------------------------------- 
Header Files:
    GADMAdapterAdColonyExtras.h
    GADMAdapterAdColonyInitializer.h

Library Name: 
    libAdapterSDKAdcolony.a

Requires:
    iOS 5.0+ (will disable itself on anything lower)

Release Date: 
    5/2/14

Integration Instructions
-------------------------------------------------- 
http://bit.ly/1m2qRXw